using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SalesOrderAPI.Models
{
    public class SalesOrder
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string SalesOrderNumber { get; set; }

        [Required]
        [StringLength(50)]
        public string CustomerCode { get; set; }

        [Required]
        [StringLength(250)]
        public string CustomerName { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }

        [Required]
        [Range(0.01, double.MaxValue)]
        public decimal TotalAmount { get; set; }

        public ICollection<SalesOrderLine> SalesOrderLines { get; set; }
    }
}
