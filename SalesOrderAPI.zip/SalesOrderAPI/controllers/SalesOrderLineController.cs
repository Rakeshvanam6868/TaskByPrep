using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesOrderAPI.Data;
using SalesOrderAPI.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesOrderAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesOrderLineController : ControllerBase
    {
        private readonly SalesOrderDbContext _context;

        public SalesOrderLineController(SalesOrderDbContext context)
        {
            _context = context;
        }

        // GET: api/SalesOrderLine
        [HttpGet]
        public async Task<ActionResult<IEnumerable<SalesOrderLine>>> GetSalesOrderLines()
        {
            return await _context.SalesOrderLines.Include(s => s.SalesOrder).ToListAsync();
        }

        // GET: api/SalesOrderLine/5
        [HttpGet("{id}")]
        public async Task<ActionResult<SalesOrderLine>> GetSalesOrderLine(int id)
        {
            var salesOrderLine = await _context.SalesOrderLines.Include(s => s.SalesOrder)
                                                                .FirstOrDefaultAsync(s => s.Id == id);

            if (salesOrderLine == null)
            {
                return NotFound();
            }

            return salesOrderLine;
        }

        // POST: api/SalesOrderLine
        [HttpPost]
        public async Task<ActionResult<SalesOrderLine>> CreateSalesOrderLine(SalesOrderLine salesOrderLine)
        {
            // Ensure that the SalesOrderId exists
            var salesOrderExists = await _context.SalesOrders.AnyAsync(s => s.Id == salesOrderLine.SalesOrderId);
            if (!salesOrderExists)
            {
                return BadRequest("SalesOrderId does not exist.");
            }

            _context.SalesOrderLines.Add(salesOrderLine);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSalesOrderLine", new { id = salesOrderLine.Id }, salesOrderLine);
        }

        // PUT: api/SalesOrderLine/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSalesOrderLine(int id, SalesOrderLine salesOrderLine)
        {
            if (id != salesOrderLine.Id)
            {
                return BadRequest();
            }

            _context.Entry(salesOrderLine).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SalesOrderLineExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/SalesOrderLine/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSalesOrderLine(int id)
        {
            var salesOrderLine = await _context.SalesOrderLines.FindAsync(id);
            if (salesOrderLine == null)
            {
                return NotFound();
            }

            _context.SalesOrderLines.Remove(salesOrderLine);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SalesOrderLineExists(int id)
        {
            return _context.SalesOrderLines.Any(e => e.Id == id);
        }
    }
}
