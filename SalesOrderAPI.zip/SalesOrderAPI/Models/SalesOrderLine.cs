using System.ComponentModel.DataAnnotations;

namespace SalesOrderAPI.Models
{
    public class SalesOrderLine
    {
        public int Id { get; set; }

        public int SalesOrderId { get; set; }
        public SalesOrder SalesOrder { get; set; }

        [Required]
        [StringLength(50)]
        public string ItemCode { get; set; }

        [Required]
        [StringLength(250)]
        public string ItemName { get; set; }

        [Required]
        public decimal UnitPrice { get; set; }

        [Required]
        public decimal Quantity { get; set; }

        public decimal TotalPrice => UnitPrice * Quantity;
    }
}
