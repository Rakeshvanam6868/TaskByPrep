using Microsoft.EntityFrameworkCore;
using SalesOrderAPI.Models;

namespace SalesOrderAPI.Data
{
    public class SalesOrderDbContext : DbContext
    {
        public SalesOrderDbContext(DbContextOptions<SalesOrderDbContext> options) : base(options)
        { }

        public DbSet<SalesOrder> SalesOrders { get; set; }
        public DbSet<SalesOrderLine> SalesOrderLines { get; set; }
    }
}
